import React, {useEffect} from 'react';
import {fetchUsers} from "./store/redusers/userSlice";
import {useAppDispatch, useAppSelector} from "./hooks/hooks";

const UserView = () => {

    const state = useAppSelector(state => state.user);
    const dispatch = useAppDispatch();
    useEffect(() => {
        dispatch(fetchUsers());
    }, []);

    return (
        <div>
            <h2>List of Users</h2>
            {state.loading && <div>Loading...</div>}
            {!state.loading && state.error ? <div>Error: {state.error}</div> : null}
            {!state.loading && state.users.length ? (
                <ul>
                    {state.users.map((user, index) => <li key={index}>{user.name}</li>)}
                </ul>
            ) : null
            }
        </div>
    );
};

export default UserView;
