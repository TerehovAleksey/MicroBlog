import { configureStore } from '@reduxjs/toolkit';
import productReducer from './redusers/productSlice';
import userReducer from './redusers/userSlice';

const store = configureStore({
    reducer: {
        product: productReducer,
        user: userReducer
    }
});

export default store;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch =  typeof store.dispatch;
