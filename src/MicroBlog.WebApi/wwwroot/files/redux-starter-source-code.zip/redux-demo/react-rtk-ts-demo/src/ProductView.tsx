import React from 'react';
import {ordered, restocked} from "./store/redusers/productSlice";
import {useAppDispatch, useAppSelector} from "./hooks/hooks";

const ProductView = () => {

    const numOfProducts = useAppSelector(state => state.product.numOfProducts);
    const dispatch = useAppDispatch();

    return (
        <div>
            <h2>Number of products - {numOfProducts}</h2>
            <button onClick={() => dispatch(ordered(null))}>Order product</button>
            <button onClick={() => dispatch(restocked(5))}>Restock product</button>
        </div>
    );
};

export default ProductView;
