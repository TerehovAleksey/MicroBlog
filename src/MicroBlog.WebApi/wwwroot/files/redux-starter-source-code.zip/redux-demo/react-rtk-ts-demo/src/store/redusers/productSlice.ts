import {createSlice, PayloadAction} from '@reduxjs/toolkit';

type ProductState = {
    numOfProducts: number
}

const initialState: ProductState = {
    numOfProducts: 10
}

const productSlice = createSlice({
    name: 'product',
    initialState,
    reducers: {
        ordered: (state, action) => {
            state.numOfProducts--;
        },
        restocked: (state, action : PayloadAction<number>) => {
            state.numOfProducts += action.payload;
        }
    }
});

export default productSlice.reducer;
export const { ordered, restocked } = productSlice.actions;
