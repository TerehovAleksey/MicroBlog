import './App.css'
import ProductView from "./ProductView";
import UserView from "./UserView";

function App() {
    return (
        <div className="App">
            <ProductView/>
            <UserView/>
        </div>
    )
}

export default App
