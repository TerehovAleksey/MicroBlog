const redux = require('redux');
const reduxLogger = require('redux-logger').createLogger();

const PRODUCT_A_ORDERED = 'PRODUCT_A_ORDERED';
const PRODUCT_A_RESTOCKED = 'PRODUCT_A_RESTOCKED';

const PRODUCT_B_ORDERED = 'PRODUCT_B_ORDERED';
const PRODUCT_B_RESTOCKED = 'PRODUCT_B_RESTOCKED';

//action creator - возвращает action (объект со свойством type)
function orderProductA() {
    return ({
        type: PRODUCT_A_ORDERED,
        payload: 1,
    })
}

function restockProductA(quantity = 1) {
    return ({
        type: PRODUCT_A_RESTOCKED,
        payload: quantity,
    });
}

function orderProductB() {
    return ({
        type: PRODUCT_B_ORDERED,
        payload: 1,
    })
}

function restockProductB(quantity = 1) {
    return ({
        type: PRODUCT_B_RESTOCKED,
        payload: quantity,
    });
}

//начальное состояние
const initialStateA = {
    numOfProduct: 10
}

const initialStateB = {
    numOfProduct: 20
}

//reducer
const productAReducer = (state = initialStateA, action) => {
    switch (action.type) {
        case PRODUCT_A_ORDERED:
            return ({
                ...state,
                numOfProduct: state.numOfProduct - action.payload
            });
        case PRODUCT_A_RESTOCKED:
            return ({
                ...state,
                numOfProduct:  state.numOfProduct + action.payload
            });
        default:
            return state;
    }
};

const productBReducer = (state = initialStateB, action) => {
    switch (action.type) {
        case PRODUCT_B_ORDERED:
            return ({
                ...state,
                numOfProduct: state.numOfProduct - action.payload
            });
        case PRODUCT_B_RESTOCKED:
            return ({
                ...state,
                numOfProduct:  state.numOfProduct + action.payload
            });
        default:
            return state;
    }
};

//создаём root-reducer
const rootReduser = redux.combineReducers({
   productA: productAReducer,
   productB: productBReducer
});
//создаём Store
const store = redux.createStore(rootReduser, redux.applyMiddleware(reduxLogger));
//console.log('Initial state', store.getState());

//подписываемся на обновления
const unsubscribe = store.subscribe(() => {});

const actions = redux.bindActionCreators({orderProductA, restockProductA, orderProductB, restockProductB}, store.dispatch);

//обновляем
actions.orderProductA();
actions.orderProductA();
actions.orderProductB();
actions.restockProductA(2);
actions.restockProductB();

//отписываемся
unsubscribe();