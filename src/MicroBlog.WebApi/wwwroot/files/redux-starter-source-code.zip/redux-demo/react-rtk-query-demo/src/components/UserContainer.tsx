import React from 'react';
import {userAPI} from "../services/userService";

const UserContainer = () => {

    //обновив параметр, автоматически будет выполнен новый запрос
    const {data: users, isLoading, isError, error} = userAPI.useFetchAllUsersQuery(5);

    return (
        <div>
            {users && users.map(user => <p key={user.id}>{user.name}</p>)}
        </div>
    );
};

export default UserContainer;
