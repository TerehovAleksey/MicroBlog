//по умолчанию среда импортирует по другому пути
//import { createApi } from '@reduxjs/toolkit/query'
//но импорт по этому пути будет нам автоматически генерировать хуки
//на основе описанных ниже эндпоинтов
import {createApi, fetchBaseQuery} from "@reduxjs/toolkit/query/react";
import {IUser} from "../models/IUser";

export const userAPI = createApi({
    reducerPath: 'userAPI',
    baseQuery: fetchBaseQuery({
        baseUrl: "https://jsonplaceholder.typicode.com"
    }),
    //тег позволяет переполучить данные, когда будет признан невалидным,
    //то есть при create, update, delete в этом примере
    tagTypes: ['User'],
    endpoints: build => ({
        //будет сгенерирован хук useFetchAllUsersQuery
        //запрос будет GET: https://jsonplaceholder.typicode.com/users&_limit=5
        fetchAllUsers: build.query<IUser[], number>({
            query: (limit = 5) => ({
                url: '/users',
                params: {
                    _limit: limit
                }
            }),
            providesTags: ["User"]
        }),
        //точно так же будет сгенерирован хук
        createUser: build.mutation<IUser, IUser>({
            query: (user) => ({
                url: `/user/${user.id}`,
                method: 'POST',
                body: user
            }),
            invalidatesTags: ["User"]
        }),
        updateUser: build.mutation<IUser, IUser>({
            query: (user) => ({
                url: `/user/${user.id}`,
                method: 'PUT',
                body: user
            }),
            invalidatesTags: ["User"]
        }),
        deleteUser: build.mutation<IUser, IUser>({
            query: (user) => ({
                url: `/user/${user.id}`,
                method: 'DELETE'
            }),
            invalidatesTags: ["User"]
        }),
    })
});
