import {configureStore} from '@reduxjs/toolkit';
import {userAPI} from "../services/userService";

const store = configureStore({
    reducer: {
        //регистрируем редюсер
        [userAPI.reducerPath]: userAPI.reducer
    },
    //добавляем middleware
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(userAPI.middleware)
});

export default store;
export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
