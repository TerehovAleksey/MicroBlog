const createSlice = require('@reduxjs/toolkit').createSlice;

const initialState = {
    numOfProducts: 10
}

const productSlice = createSlice({
    name: 'product',
    initialState,
    reducers: {
        //объкты теперь изменяемые
        ordered: (state, action) => {
            state.numOfProducts--;
        },
        restocked: (state, action) => {
            state.numOfProducts += action.payload;
        }
    }
});

module.exports = productSlice.reducer;
module.exports.productActions = productSlice.actions;