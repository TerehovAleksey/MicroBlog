const store = require('./app/store');
const productActions = require('./features/product/productSlice').productActions;
const fetchUsers = require('./features/user/userSlice').fetchUsers;

console.log('Initial state', store.getState());
const unsubscribe = store.subscribe(() => {});

store.dispatch(fetchUsers());

// store.dispatch(productActions.ordered());
// store.dispatch(productActions.ordered());
// store.dispatch(productActions.ordered());
// store.dispatch(productActions.restocked(3));

unsubscribe();