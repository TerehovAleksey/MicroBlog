const configureStore = require('@reduxjs/toolkit').configureStore;
const logger = require('redux-logger').createLogger();
const productReducer = require('../features/product/productSlice');
const userReducer = require('../features/user/userSlice');

const store = configureStore({
    reducer: {
        product: productReducer,
        user: userReducer
    },
    middleware: (getDefaultMiddleware) => getDefaultMiddleware().concat(logger),
});

module.exports = store;