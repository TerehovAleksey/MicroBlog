import React from 'react';
import {useSelector, useDispatch} from "react-redux";
import {ordered, restocked} from './productSlice.js';

const ProductView = () => {

    const numOfProducts = useSelector(state => state.product.numOfProducts);
    const dispatch = useDispatch();

    return (
        <div>
            <h2>Number of products - {numOfProducts}</h2>
            <button onClick={() => dispatch(ordered())}>Order product</button>
            <button onClick={() => dispatch(restocked(5))}>Restock product</button>
        </div>
    );
};

export default ProductView;
