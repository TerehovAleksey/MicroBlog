import {useState} from 'react'
import './App.css'
import ProductView from "./features/product/ProductView.jsx";
import UserView from "./features/user/UserView.jsx";

function App() {
    return (
        <div className="App">
            <ProductView/>
            <UserView/>
        </div>
    )
}

export default App
