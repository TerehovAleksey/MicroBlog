import { createSlice } from '@reduxjs/toolkit';

const initialState = {
    numOfProducts: 10
}

const productSlice = createSlice({
    name: 'product',
    initialState,
    reducers: {
        //объкты теперь изменяемые
        ordered: (state, action) => {
            state.numOfProducts--;
        },
        restocked: (state, action) => {
            state.numOfProducts += action.payload;
        }
    }
});

export default productSlice.reducer;
export const { ordered, restocked } = productSlice.actions;